// Json web token
module.exports={
    JWT_SECRET:"assddsa"
}